
/* menu amburguesa */
hamburguesa = document.querySelector('.hamburguesa');
hamburguesa.onclick = function(){
	navBar = document.querySelector('nav');
	navBar.classList.toggle("active");
}
